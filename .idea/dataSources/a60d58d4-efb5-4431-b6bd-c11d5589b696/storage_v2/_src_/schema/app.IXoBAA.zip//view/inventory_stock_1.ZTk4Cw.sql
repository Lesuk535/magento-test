create definer = app@`%` view inventory_stock_1 as
select distinct `legacy_stock_status`.`product_id`   AS `product_id`,
                `legacy_stock_status`.`website_id`   AS `website_id`,
                `legacy_stock_status`.`stock_id`     AS `stock_id`,
                `legacy_stock_status`.`qty`          AS `quantity`,
                `legacy_stock_status`.`stock_status` AS `is_salable`,
                `product`.`sku`                      AS `sku`
from (`app`.`cataloginventory_stock_status` `legacy_stock_status`
         join `app`.`catalog_product_entity` `product`
              on ((`legacy_stock_status`.`product_id` = `product`.`entity_id`)));

-- comment on column inventory_stock_1.product_id not supported: Product ID

-- comment on column inventory_stock_1.website_id not supported: Website ID

-- comment on column inventory_stock_1.stock_id not supported: Stock ID

-- comment on column inventory_stock_1.quantity not supported: Qty

-- comment on column inventory_stock_1.is_salable not supported: Stock Status

-- comment on column inventory_stock_1.sku not supported: SKU

